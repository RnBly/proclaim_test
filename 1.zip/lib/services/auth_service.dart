import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'dart:js' as js;
import 'dart:convert';
import 'dart:async';

class AuthService {
  // 싱글톤 패턴
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  // 로그인 제공자 추적
  String? _loginProvider;
  Map<String, dynamic>? _kakaoUserData;

  // 현재 로그인된 사용자 가져오기
  User? get currentUser => _auth.currentUser;

  // 로그인 상태 스트림
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // 로그인 여부 확인
  bool get isLoggedIn => _auth.currentUser != null;

  // Google 로그인
  Future<UserCredential?> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();

      if (googleUser == null) {
        return null;
      }

      final GoogleSignInAuthentication googleAuth =
      await googleUser.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCredential = await _auth.signInWithCredential(credential);

      _loginProvider = 'google';
      print('✅ Google 로그인 성공: ${userCredential.user?.displayName}');
      return userCredential;
    } catch (e) {
      print('❌ Google 로그인 실패: $e');
      return null;
    }
  }

  // Kakao 로그인 (JavaScript 호출)
  // Kakao 로그인 (JavaScript 호출)
  Future<UserCredential?> signInWithKakao() async {
    try {
      // JavaScript의 kakaoLogin.login 함수 호출
      final kakaoLoginObj = js.context['kakaoLogin'];
      final jsPromise = kakaoLoginObj.callMethod('login');

      // Promise를 Future로 변환
      final result = await _promiseToFuture(jsPromise);

      if (result == null) {
        print('❌ Kakao 로그인 취소');
        return null;
      }

      // 사용자 데이터 파싱 (이미 객체로 반환됨)
      final jsUserInfo = result as js.JsObject;
      final kakaoId = jsUserInfo['id'].toString();
      final nickname = jsUserInfo['nickname'].toString();
      final profileImage = jsUserInfo['profileImage'].toString();
      final email = jsUserInfo['email']?.toString() ?? '';

// Map으로 저장
      final userInfo = {
        'id': kakaoId,
        'nickname': nickname,
        'profileImage': profileImage,
        'email': email,
      };

      print('✅ Kakao 사용자 정보: ID=$kakaoId, 닉네임=$nickname');

      // Firebase 익명 로그인
      final userCredential = await _auth.signInAnonymously();

      // 프로필 업데이트
      await userCredential.user?.updateDisplayName(nickname);
      if (profileImage.isNotEmpty) {
        await userCredential.user?.updatePhotoURL(profileImage);
      }

      _loginProvider = 'kakao';
      _kakaoUserData = userInfo;
      print('✅ Kakao 로그인 성공: $nickname');
      return userCredential;
    } catch (e) {
      print('❌ Kakao 로그인 실패: $e');
      return null;
    }
  }

  // JavaScript Promise를 Dart Future로 변환
  Future<dynamic> _promiseToFuture(js.JsObject jsPromise) async {
    final completer = Completer<dynamic>();

    jsPromise.callMethod('then', [
          (value) {
        completer.complete(value);
      }
    ]);

    jsPromise.callMethod('catch', [
          (error) {
        completer.completeError(error);
      }
    ]);

    return completer.future;
  }

  // 로그아웃
  Future<void> signOut() async {
    try {
      final futures = <Future>[];

      if (_loginProvider == 'google') {
        futures.add(_googleSignIn.signOut());
      }

      if (_loginProvider == 'kakao') {
        try {
          final jsPromise = js.context.callMethod('kakaoLogout');
          await _promiseToFuture(jsPromise);
        } catch (e) {
          print('Kakao 로그아웃 오류 (무시): $e');
        }
      }

      futures.add(_auth.signOut());

      await Future.wait(futures);
      _loginProvider = null;
      _kakaoUserData = null;
      print('✅ 로그아웃 완료');
    } catch (e) {
      print('❌ 로그아웃 실패: $e');
    }
  }

  // 사용자 정보 가져오기
  String? getUserName() => _auth.currentUser?.displayName;
  String? getUserEmail() => _auth.currentUser?.email;
  String? getUserPhoto() => _auth.currentUser?.photoURL;
  String? getUserId() => _auth.currentUser?.uid;
  String? getLoginProvider() => _loginProvider;
}