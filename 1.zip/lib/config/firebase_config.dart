import 'package:firebase_core/firebase_core.dart';

class FirebaseConfig {
  static const firebaseConfig = FirebaseOptions(
      apiKey: "AIzaSyBcz7EqfkqRcYgsZz7KpPmhKQbB03uJAeQ",
      authDomain: "proclaim-test.firebaseapp.com",
      projectId: "proclaim-test",
      storageBucket: "proclaim-test.firebasestorage.app",
      messagingSenderId: "105613158198",
      appId: "1:105613158198:web:f33cd2b0f702f3adcff597",
      measurementId: "G-6FP85HL9BV"
  );
}