class KakaoConfig {
  static const String nativeAppKey = '1f81782276e5a2334a8c9df7d0a743d7';
  static const String javascriptKey = '612fc750b7a77a16cb1b52e406c1073d';
}