// lib/config/secrets.dart

class Secrets {
  // ===== Google Sheets 설정 =====

  /// Spreadsheet ID
  /// URL: https://docs.google.com/spreadsheets/d/[이_부분]/edit
  static const String SPREADSHEET_ID = '1dzHDX6LYR0qzkijQ_bWMBlSQGhGrMj4S';

  /// 시트 이름들
  static const String OLD_TESTAMENT_SHEET = 'Old Testament';
  static const String PSALMS_SHEET = 'Psalms';
  static const String NEW_TESTAMENT_SHEET = 'New Testament';

  // ===== GitHub URLs =====

  static const String BIBLE_JSON_URL =
      'https://raw.githubusercontent.com/RnBly/proclaim-app/main/assets/bible.json';

  static const String BIBLE_ESV_JSON_URL =
      'https://raw.githubusercontent.com/RnBly/proclaim-app/main/assets/bible_esv.json';

  // ===== Google Sheets URL 생성 =====

  static String getSheetCsvUrl(String sheetName) {
    return 'https://docs.google.com/spreadsheets/d/$SPREADSHEET_ID/gviz/tq?tqx=out:csv&sheet=$sheetName';
  }
}